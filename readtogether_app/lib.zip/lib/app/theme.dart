import 'package:flutter/material.dart';

ThemeData get appTheme => ThemeData(
      colorSchemeSeed: const Color(0xFF40535c),
      useMaterial3: true,
    );