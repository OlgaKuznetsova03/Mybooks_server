import 'package:flutter/material.dart';

import '../../services/api_service.dart';
import '../web_view/web_view_page.dart';
import 'widgets.dart';

final _palette = <Color>[
  const Color(0xFF7DA2FF),
  const Color(0xFFFFD166),
  const Color(0xFF6EE7B7),
  const Color(0xFFFF9BC1),
  const Color(0xFFB28DFF),
  const Color(0xFF96E8FF),
  const Color(0xFFFFD080),
  const Color(0xFFF6C2FF),
];

String _formatDate(DateTime? value) {
  if (value == null) return '';
  final day = value.day.toString().padLeft(2, '0');
  final month = value.month.toString().padLeft(2, '0');
  return '$day.$month.${value.year}';
}

String _formatDateTime(DateTime? value) {
  if (value == null) return '';
  final date = _formatDate(value);
  final hours = value.hour.toString().padLeft(2, '0');
  final minutes = value.minute.toString().padLeft(2, '0');
  return '$date, $hours:$minutes';
}

double _timelineProgress(DateTime? start, DateTime? end) {
  if (start == null || end == null || end.isBefore(start)) return 0;
  final now = DateTime.now();
  if (now.isBefore(start)) return 0;
  if (now.isAfter(end)) return 1;
  final total = end.difference(start).inSeconds;
  if (total <= 0) return 0;
  final passed = now.difference(start).inSeconds;
  return (passed / total).clamp(0, 1).toDouble();
}

class HomeExperiencePage extends StatefulWidget {
  const HomeExperiencePage({super.key});

  @override
  State<HomeExperiencePage> createState() => _HomeExperiencePageState();
}

class _HomeExperiencePageState extends State<HomeExperiencePage> {
  final MobileApiService _api = MobileApiService();
  late final Future<HomeFeed> _future = _api.fetchHomeFeed();

  @override
  Widget build(BuildContext context) {
    return _AsyncExperience(
      future: _future,
      builder: (data) => ExperienceLayout(
        title: data.hero.headline,
        subtitle: data.hero.subtitle,
        hero: _HomeHeroBanner(hero: data.hero, stats: _homeStats(data)),
        sections: [
          ExperienceSection(
            title: 'Полка «Читаю»',
            description: 'Личные книги и прогресс загружаются из /api/v1/home/.',
            cards: _readingCards(context, data.readingItems),
          ),
          ExperienceSection(
            title: 'Активные клубы',
            description: 'Живые обсуждения с книгами и датами из общего API.',
            cards: _clubTiles(context, data.activeClubs),
          ),
          ExperienceSection(
            title: 'Марафоны',
            description: 'Статус и прогресс марафонов, рассчитанный по датам.',
            cards: _marathonCards(context, data.activeMarathons),
          ),
        ],
      ),
    );
  }
}

class BooksExperiencePage extends StatefulWidget {
  const BooksExperiencePage({super.key});

  @override
  State<BooksExperiencePage> createState() => _BooksExperiencePageState();
}

class _BooksExperiencePageState extends State<BooksExperiencePage> {
  final MobileApiService _api = MobileApiService();
  late final Future<List<BookSummary>> _future = _api.fetchBooks(pageSize: 12);
  late final Future<List<ReadingClubSummary>> _clubFuture = _api.fetchReadingClubs(pageSize: 4);

  @override
  Widget build(BuildContext context) {
    return _AsyncExperience(
      future: Future.wait([
        _future,
        _clubFuture,
      ]),
      builder: (payload) {
        final books = payload[0] as List<BookSummary>;
        final clubs = payload[1] as List<ReadingClubSummary>;
        final spotlight = books.take(6).toList();
        final more = books.skip(6).take(6).toList();

        return ExperienceLayout(
          title: 'Книги',
          subtitle: 'Каталог на реальных данных: жанры, авторы, языки',
          hero: GlassCard(
            gradient: const [Color(0xFF2563EB), Color(0xFF38BDF8)],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Каталог переизобретён'),
                const SizedBox(height: 8),
                Text(
                  'Карточки строятся из API: жанры, аннотации, языки, средний рейтинг.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white70),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 12,
                  runSpacing: 8,
                  children: const [
                    QuickBadge(label: 'Аннотация'),
                    QuickBadge(label: 'Жанры'),
                    QuickBadge(label: 'Авторы'),
                  ],
                ),
              ],
            ),
          ),
          sections: [
            ExperienceSection(
              title: 'Подборки недели',
              description: 'Свежие книги с жанрами и описанием.',
              cards: _bookCards(context, spotlight),
            ),
            ExperienceSection(
              title: 'Ещё книги',␊
              description: 'Расширенный список по ответу API.',
              cards: _bookCards(context, more),
            ),
            ExperienceSection(
              title: 'Клубы вокруг этих книг',
              description: 'Связанные книги и статус клубов.',
              cards: _clubTiles(context, clubs),
            ),
          ],
        );
      },
    );
  }
}

class ReadingNowPage extends StatefulWidget {
  const ReadingNowPage({super.key});

  @override
  State<ReadingNowPage> createState() => _ReadingNowPageState();
}

class _ReadingNowPageState extends State<ReadingNowPage> {
  final MobileApiService _api = MobileApiService();
  late final Future<List<ReadingClubSummary>> _clubs = _api.fetchReadingClubs(pageSize: 6);
  late final Future<List<ReadingMarathonSummary>> _marathons = _api.fetchMarathons(pageSize: 6);

  @override
  Widget build(BuildContext context) {
    return _AsyncExperience(
      future: Future.wait([
        _clubs,
        _marathons,
      ]),
      builder: (payload) {
        final clubs = payload[0] as List<ReadingClubSummary>;
        final marathons = payload[1] as List<ReadingMarathonSummary>;

        return ExperienceLayout(
          title: 'Читаю сейчас',
          subtitle: 'Фокус на активных клубах и марафонах в реальном времени',
          hero: GlassCard(
            gradient: const [Color(0xFFFB923C), Color(0xFFF97316)],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Режим концентрации'),
                const SizedBox(height: 10),
                Text(
                  'Используем даты и статус клубов/марафонов вместо заглушек.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white70),
                ),
                const SizedBox(height: 14),
                const QuickBadge(label: 'Реальные даты стартов'),
              ],
            ),
          ),
          sections: [
            ExperienceSection(
              title: 'Клубные сессии',
              description: 'Даты, статус и количество сообщений.',
              cards: _clubTiles(context, clubs),
            ),
            ExperienceSection(
              title: 'Марафоны в работе',
              description: 'Прогресс рассчитывается по времени проведения.',
              cards: _marathonCards(context, marathons),
            ),
          ],
        );
      },
    );
  }
}

class HomeLibraryPage extends StatefulWidget {
  const HomeLibraryPage({super.key});

  @override
  State<HomeLibraryPage> createState() => _HomeLibraryPageState();
}

class _HomeLibraryPageState extends State<HomeLibraryPage> {
  final MobileApiService _api = MobileApiService();
  late final Future<FeatureMap> _featureMap = _api.fetchFeatureMap();
  late final Future<List<BookSummary>> _books = _api.fetchBooks(pageSize: 6);

  @override
  Widget build(BuildContext context) {
    return _AsyncExperience(
      future: Future.wait([
        _featureMap,
        _books,
      ]),
      builder: (payload) {
        final feature = payload[0] as FeatureMap;
        final books = payload[1] as List<BookSummary>;

        return ExperienceLayout(
          title: 'Домашняя библиотека',
          subtitle: 'Показываем, что доступно через API, и быстрые ссылки на книги',
          hero: GlassCard(
            gradient: const [Color(0xFF22C55E), Color(0xFF14B8A6)],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Полный контроль'),
                const SizedBox(height: 10),
                Text(
                  'Отображаем реальные эндпоинты и книги, чтобы библиотека была прозрачной.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white70),
                ),
                const SizedBox(height: 12),
                const QuickBadge(label: 'API-first'),
              ],
            ),
          ),
          sections: [
            ExperienceSection(
              title: 'Эндпоинты библиотеки',
              description: 'Статусы доступности функций по карте API.',
              cards: _featureMapCards(context, feature),
            ),
            ExperienceSection(
              title: 'Недавно добавленные книги',
              description: 'Используем свежие книги из каталога.',
              cards: _bookCards(context, books),
            ),
          ],
        );
      },
    );
  }
}

class CoReadingPage extends StatefulWidget {
  const CoReadingPage({super.key});

  @override
  State<CoReadingPage> createState() => _CoReadingPageState();
}

class _CoReadingPageState extends State<CoReadingPage> {
  final MobileApiService _api = MobileApiService();
  late final Future<List<ReadingClubSummary>> _future = _api.fetchReadingClubs(pageSize: 10);

  @override
  Widget build(BuildContext context) {
    return _AsyncExperience(
      future: _future,
      builder: (clubs) => ExperienceLayout(
        title: 'Совместные чтения',
        subtitle: 'Данные о клубах приходят напрямую из API',
        hero: GlassCard(
          gradient: const [Color(0xFFFF9BC1), Color(0xFFE879F9)],
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Общайтесь и читайте вместе'),
              const SizedBox(height: 8),
              Text(
                'Показываем статус, политику вступления и книгу клуба.',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white70),
              ),
            ],
          ),
        ),
        sections: [
          ExperienceSection(
            title: 'Клубы',
            description: 'Вся метаинформация доступна без заглушек.',
            cards: _clubTiles(context, clubs),
          ),
        ],
      ),
    );
  }
}

class MarathonsPage extends StatefulWidget {
  const MarathonsPage({super.key});

  @override
  State<MarathonsPage> createState() => _MarathonsPageState();
}

class _MarathonsPageState extends State<MarathonsPage> {
  final MobileApiService _api = MobileApiService();
  late final Future<List<ReadingMarathonSummary>> _future = _api.fetchMarathons(pageSize: 10);

  @override
  Widget build(BuildContext context) {
    return _AsyncExperience(
      future: _future,
      builder: (marathons) => ExperienceLayout(
        title: 'Марафоны',
        subtitle: 'Живые данные о марафонах: даты, статус, участники',
        hero: GlassCard(
          gradient: const [Color(0xFFB28DFF), Color(0xFF6366F1)],
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Держим темп'),
              const SizedBox(height: 8),
              Text(
                'Прогресс считаем по времени проведения марафона.',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white70),
              ),
            ],
          ),
        ),
        sections: [
          ExperienceSection(
            title: 'Активные марафоны',
            description: 'Из API без выдуманных данных.',
            cards: _marathonCards(context, marathons),
          ),
        ],
      ),
    );
  }
}

class GamesPage extends StatefulWidget {
  const GamesPage({super.key});

  @override
  State<GamesPage> createState() => _GamesPageState();
}

class _GamesPageState extends State<GamesPage> {
  final MobileApiService _api = MobileApiService();
  late final Future<FeatureMap> _future = _api.fetchFeatureMap();

  @override
  Widget build(BuildContext context) {
    return _AsyncExperience(
      future: _future,
      builder: (featureMap) => ExperienceLayout(
        title: 'Игры',
        subtitle: 'Показываем статус игровых эндпоинтов',
        hero: GlassCard(
          gradient: const [Color(0xFF96E8FF), Color(0xFF22D3EE)],
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Геймификация'),
              const SizedBox(height: 8),
              Text(
                'Выводим статусы будущих игровых API, без фиктивных карточек.',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white70),
              ),
            ],
          ),
        ),
        sections: [
          ExperienceSection(
            title: 'Эндпоинты игр',
            description: 'Используем карту возможностей сервиса.',
            cards: _featureGroupCards(context, featureMap, 'games'),
          ),
        ],
      ),
    );
  }
}

class ReviewsPage extends StatefulWidget {
  const ReviewsPage({super.key});

  @override
  State<ReviewsPage> createState() => _ReviewsPageState();
}

class _ReviewsPageState extends State<ReviewsPage> {
  final MobileApiService _api = MobileApiService();
  late final Future<List<BookSummary>> _future = _api.fetchBooks(pageSize: 10);

  @override
  Widget build(BuildContext context) {
    return _AsyncExperience(
      future: _future,
      builder: (books) {
        final sorted = [...books]..sort((a, b) => (b.averageRating ?? 0).compareTo(a.averageRating ?? 0));
        return ExperienceLayout(
          title: 'Отзывы и рейтинг',
          subtitle: 'Используем реальные рейтинги и данные книг',
          hero: GlassCard(
            gradient: const [Color(0xFFFFD080), Color(0xFFFFA94D)],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Честные рейтинги'),
                const SizedBox(height: 8),
                Text(
                  'Сортируем книги по среднему рейтингу из API.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white70),
                ),
              ],
            ),
          ),
          sections: [
          ExperienceSection(
            title: 'Лидеры рейтинга',
            description: 'Без заглушек: реальные книги и оценки.',
            cards: _ratingCards(context, sorted),
          ),
        ],
      );
    },
    );
  }
}

class CollaborationPage extends StatefulWidget {
  const CollaborationPage({super.key});

  @override
  State<CollaborationPage> createState() => _CollaborationPageState();
}

class _CollaborationPageState extends State<CollaborationPage> {
  final MobileApiService _api = MobileApiService();
  late final Future<FeatureMap> _future = _api.fetchFeatureMap();

  @override
  Widget build(BuildContext context) {
    return _AsyncExperience(
      future: _future,
      builder: (featureMap) => ExperienceLayout(
        title: 'Сотрудничество',
        subtitle: 'Статусы API для коллабораций и сообществ',
        hero: GlassCard(
          gradient: const [Color(0xFF7CFFB2), Color(0xFF34D399)],
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Работа с партнёрами'),
              const SizedBox(height: 8),
              Text(
                'Отображаем карту возможностей для сообществ.',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white70),
              ),
            ],
          ),
        ),
        sections: [
          ExperienceSection(
            title: 'Комьюнити',
            description: 'Готовые и планируемые эндпоинты.',
            cards: _featureGroupCards(context, featureMap, 'communities'),
          ),
        ],
      ),
    );
  }
}

class BloggerHubPage extends StatefulWidget {
  const BloggerHubPage({super.key});

  @override
  State<BloggerHubPage> createState() => _BloggerHubPageState();
}

class _BloggerHubPageState extends State<BloggerHubPage> {
  final MobileApiService _api = MobileApiService();
  late final Future<FeatureMap> _future = _api.fetchFeatureMap();

  @override
  Widget build(BuildContext context) {
    return _AsyncExperience(
      future: _future,
      builder: (featureMap) => ExperienceLayout(
        title: 'Блогерский хаб',
        subtitle: 'Никаких заглушек — только карта возможностей',
        hero: GlassCard(
          gradient: const [Color(0xFF9AE6FF), Color(0xFF38BDF8)],
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Все потоки контента'),
              const SizedBox(height: 8),
              Text(
                'Показываем, что уже доступно и что в планах.',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white70),
              ),
            ],
          ),
        ),
        sections: [
          ExperienceSection(
            title: 'Возможности',
            description: 'Статусы API для блогеров и аудиторий.',
            cards: _featureMapCards(context, featureMap),
          ),
        ],
      ),
    );
  }
}

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key});

  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  final MobileApiService _api = MobileApiService();
  late final Future<FeatureMap> _future = _api.fetchFeatureMap();

  @override
  Widget build(BuildContext context) {
    return _AsyncExperience(
      future: _future,
      builder: (featureMap) => ExperienceLayout(
        title: 'Уведомления',
        subtitle: 'Следим за статусом эндпоинтов профиля',
        hero: GlassCard(
          gradient: const [Color(0xFFFF9F80), Color(0xFFF97316)],
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Сигналы и события'),
              const SizedBox(height: 8),
              Text(
                'Используем карту возможностей профиля вместо фиктивных уведомлений.',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white70),
              ),
            ],
          ),
        ),
        sections: [
          ExperienceSection(
            title: 'Профиль и подписки',
            description: 'Текущее состояние API, чтобы понимать, что доступно.',
            cards: _featureGroupCards(context, featureMap, 'profile'),
          ),
        ],
      ),
    );
  }
}

class PremiumPage extends StatefulWidget {
  const PremiumPage({super.key});

  @override
  State<PremiumPage> createState() => _PremiumPageState();
}

class _PremiumPageState extends State<PremiumPage> {
  final MobileApiService _api = MobileApiService();
  late final Future<FeatureMap> _future = _api.fetchFeatureMap();
  late final Future<List<BookSummary>> _books = _api.fetchBooks(pageSize: 4);

  @override
  Widget build(BuildContext context) {
    return _AsyncExperience(
      future: Future.wait([
        _future,
        _books,
      ]),
      builder: (payload) {
        final feature = payload[0] as FeatureMap;
        final books = payload[1] as List<BookSummary>;
        return ExperienceLayout(
          title: 'Премиум',
          subtitle: 'Прозрачные статусы подписки и отобранные книги',
          hero: GlassCard(
            gradient: const [Color(0xFFF6C2FF), Color(0xFF7C3AED)],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Лучшее из каталога'),
                const SizedBox(height: 8),
                Text(
                  'Подсвечиваем доступность подписки и рекомендуем книги из API.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white70),
                ),
              ],
            ),
          ),
          sections: [
          ExperienceSection(
            title: 'Статус подписки',
            description: 'Берём информацию из профиля/подписок в feature-map.',
            cards: _featureGroupCards(context, feature, 'profile'),
          ),
          ExperienceSection(
            title: 'Выбор редакции',
            description: 'Книги без вымышленных данных.',
            cards: _bookCards(context, books),
          ),
        ],
      );
    },
    );
  }
}

class _HomeHeroBanner extends StatelessWidget {
  const _HomeHeroBanner({required this.hero, required this.stats});

  final HomeHero hero;
  final List<String> stats;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 600),
      tween: Tween(begin: 0, end: 1),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) {
        return GlassCard(
          gradient: [
            Color.lerp(const Color(0xFF4F46E5), const Color(0xFF7C3AED), value) ?? const Color(0xFF4F46E5),
            Color.lerp(const Color(0xFF7C3AED), const Color(0xFF22D3EE), value) ?? const Color(0xFF7C3AED),
          ],
          child: child!,
        );
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(hero.headline, style: Theme.of(context).textTheme.titleLarge?.copyWith(color: Colors.white)),
          const SizedBox(height: 6),
          Text(
            hero.subtitle,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white70),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: stats.map((stat) => QuickBadge(label: stat)).toList(),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              const Icon(Icons.bolt, color: Colors.white70, size: 16),
              const SizedBox(width: 6),
              Text(
                _formatDateTime(hero.timestamp),
                style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.white70),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

List<String> _homeStats(HomeFeed feed) {
  return [
    'Клубов: ${feed.activeClubs.length}',
    'Марафонов: ${feed.activeMarathons.length}',
    'Читаю: ${feed.readingItems.length}',
  ];
}

List<Widget> _readingCards(BuildContext context, List<ReadingShelfItem> items) {
  if (items.isEmpty) {
    return const [InfoCard(icon: Icons.local_library_outlined, message: 'Нет активных книг на полке')];
  }

  final cards = <Widget>[];
  for (var i = 0; i < items.length; i++) {
    final item = items[i];
    final accent = _palette[(i + 1) % _palette.length];
    final progress = (item.progressPercent ?? 0) / 100;
    cards.add(
      ProgressCard(
        title: item.book.title,
        subtitle: _readingSubtitle(item),
        progress: progress.clamp(0, 1),
        accent: accent,
        coverUrl: item.book.coverUrl,
        onTap: () => _openPath(context, '/books/${item.book.id}/'),
      ),
    );
  }

  return cards;
}

String _readingSubtitle(ReadingShelfItem item) {
  final authors = item.book.authors.map((a) => a.name).join(', ');
  final progressLabel = item.progressLabel ?? 'Нет прогресса';
  final pages = _formatPages(item.progressCurrentPage, item.progressTotalPages);
  final updated = _formatDateTime(item.progressUpdatedAt);

  return [
    if (authors.isNotEmpty) authors,
    progressLabel,
    if (pages.isNotEmpty) pages,
    if (updated.isNotEmpty) 'обновлено $updated',
  ].join(' · ');
}

String _formatPages(int? current, int? total) {
  if (current == null && total == null) return '';
  if (current != null && total != null) return '$current / $total стр.';
  if (current != null) return '$current стр.';
  return '$total стр.';
}

class _AsyncExperience<T> extends StatelessWidget {
  const _AsyncExperience({required this.future, required this.builder});

  final Future<T> future;
  final Widget Function(T data) builder;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<T>(
      future: future,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(
            child: InfoCard(
              icon: Icons.error_outline,
              message: 'Не удалось загрузить данные: ${snapshot.error}',
            ),
          );
        }
        final data = snapshot.data;
        if (data == null) {
          return const Center(
            child: InfoCard(
              icon: Icons.hourglass_empty,
              message: 'Данные не найдены',
            ),
          );
        }
        return builder(data);
      },
    );
  }
}

List<Widget> _bookCards(BuildContext context, List<BookSummary> books) {
  if (books.isEmpty) {
    return const [
      InfoCard(icon: Icons.menu_book_outlined, message: 'Книги пока не найдены'),
    ];
  }
  final cards = <Widget>[];
  for (var i = 0; i < books.length; i++) {
    final book = books[i];
    final accent = _palette[i % _palette.length];
    cards.add(
      BookCard(
        title: book.title,
        subtitle: book.subtitle,
        tag: book.primaryTag,
        accent: accent,
        coverUrl: book.coverUrl,
        onTap: () => _openPath(context, '/books/${book.id}/'),
      ),
    );
  }
  return cards;
}

List<Widget> _clubTiles(BuildContext context, List<ReadingClubSummary> clubs) {
  if (clubs.isEmpty) {
    return const [InfoCard(icon: Icons.group_outlined, message: 'Нет активных клубов')];
  }
  return clubs
      .map(
        (club) => CompactListTile(
          icon: Icons.groups,
          title: club.title,
          subtitle: _clubSubtitle(club),
          trailing: Text(club.status, style: const TextStyle(color: Colors.white70)),
          onTap: club.slug.isNotEmpty ? () => _openPath(context, '/reading-clubs/${club.slug}/') : null,
          coverUrl: club.book?.coverUrl,
        ),
      )
      .toList();
}

String _clubSubtitle(ReadingClubSummary club) {
  final bookTitle = club.book?.title;
  final dateRange = [club.startDate, club.endDate].whereType<DateTime>().toList();
  final dateText = dateRange.isEmpty
      ? ''
      : dateRange.length == 1
          ? _formatDate(dateRange.first)
          : '${_formatDate(dateRange.first)} — ${_formatDate(dateRange.last)}';
  final details = [bookTitle, dateText].where((value) => value != null && value.isNotEmpty).join(' · ');
  if (details.isNotEmpty) return details;
  return club.description.isNotEmpty ? club.description : 'Детали клуба будут позже';
}

List<Widget> _marathonCards(BuildContext context, List<ReadingMarathonSummary> marathons) {
  if (marathons.isEmpty) {
    return const [InfoCard(icon: Icons.flag_outlined, message: 'Марафоны пока не найдены')];
  }
  final cards = <Widget>[];
  for (var i = 0; i < marathons.length; i++) {
    final marathon = marathons[i];
    final progress = _timelineProgress(marathon.startDate, marathon.endDate);
    final accent = _palette[(i + 3) % _palette.length];
    final subtitleParts = [
      if (marathon.startDate != null) 'Старт: ${_formatDate(marathon.startDate)}',
      if (marathon.endDate != null) 'Финиш: ${_formatDate(marathon.endDate)}',
      if (marathon.participantCount > 0) 'Участников: ${marathon.participantCount}',
    ];
    cards.add(
      ProgressCard(
        title: marathon.title,
        subtitle: subtitleParts.join(' · '),
        progress: progress,
        accent: accent,
        onTap: marathon.slug.isNotEmpty ? () => _openPath(context, '/marathons/${marathon.slug}/') : null,
      ),
    );
  }
  return cards;
}

List<Widget> _featureMapCards(BuildContext context, FeatureMap featureMap) {
  if (featureMap.groups.isEmpty) {
    return const [InfoCard(icon: Icons.public, message: 'Карта возможностей пустая')];
  }
  return featureMap.groups.expand((group) => _featureGroupCards(context, featureMap, group.key)).toList();
}

List<Widget> _featureGroupCards(BuildContext context, FeatureMap featureMap, String groupKey) {
  final group = featureMap.groups.firstWhere(
    (item) => item.key == groupKey,
    orElse: () => FeatureGroup(key: groupKey, description: 'Нет описания', endpoints: const []),
  );
  if (group.endpoints.isEmpty) {
    return [
      InfoCard(
        icon: Icons.info_outline,
        message: 'Для "$groupKey" пока нет доступных эндпоинтов',
      ),
    ];
  }
  return group.endpoints
      .map(
        (endpoint) => CompactListTile(
          icon: Icons.api,
          title: endpoint.path,
          subtitle: group.description,
          trailing: StatusPill(status: endpoint.status),
        ),
      )
      .toList();
}

List<Widget> _ratingCards(BuildContext context, List<BookSummary> books) {
  if (books.isEmpty) {
    return const [InfoCard(icon: Icons.star_border, message: 'Рейтинги появятся позже')];
  }
  final cards = <Widget>[];
  for (var i = 0; i < books.length; i++) {
    cards.add(
      HighlightCard(
        title: book.title,
        subtitle: book.subtitle,
        accent: accent,
        progress: (book.averageRating ?? 0) / 5,
        coverUrl: book.coverUrl,
        onTap: () => _openPath(context, '/books/${book.id}/'),
      ),
    );
    cards.add(
      CompactListTile(
        icon: Icons.star,
        title: 'Оценка: $rating',
        subtitle: book.primaryTag,
        onTap: () => _openPath(context, '/books/${book.id}/'),
      ),
    );
  }
  return cards;
}

String _normalizePath(String path) {
  if (path.isEmpty) return '/';
  final withLeading = path.startsWith('/') ? path : '/$path';
  return withLeading.endsWith('/') ? withLeading : '$withLeading/';
}

void _openPath(BuildContext context, String path) {
  final normalized = _normalizePath(path);
  Navigator.of(context).push(
    MaterialPageRoute(
      builder: (_) => MainWebViewPage(initialPath: normalized),
    ),
  );
}