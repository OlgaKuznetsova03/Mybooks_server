class AuthState {
  AuthState._();

  static final AuthState instance = AuthState._();

  String? token;
}